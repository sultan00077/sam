import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, Search, User, Heart, X, View } from 'lucide-react';

// @ts-ignore
import '@google/model-viewer';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  modelUrl?: string;
}

interface CartItem extends Product {
  quantity: number;
}

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': any;
    }
  }
}

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selected3DProduct, setSelected3DProduct] = useState<Product | null>(null);

  const products: Product[] = [
    {
      id: 1,
      name: "Wool Blend Oversized Coat",
      price: 299.99,
      image: "https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?auto=format&fit=crop&q=80&w=987",
      category: "Women",
      modelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.glb"
    },
    {
      id: 2,
      name: "Cashmere Turtleneck Sweater",
      price: 189.99,
      image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&q=80&w=1964",
      category: "Women",
      modelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.glb"
    },
    {
      id: 3,
      name: "Tailored Wool Suit",
      price: 599.99,
      image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=2080",
      category: "Men",
      modelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.glb"
    },
    {
      id: 4,
      name: "Italian Leather Jacket",
      price: 449.99,
      image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=1935",
      category: "Men",
      modelUrl: "https://modelviewer.dev/shared-assets/models/Astronaut.glb"
    }
  ];

  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <button className="p-2 rounded-md lg:hidden">
                <Menu className="h-6 w-6" />
              </button>
              <div className="hidden lg:flex lg:space-x-8 ml-8">
                <a href="#" className="text-gray-900 hover:text-gray-600">Men</a>
                <a href="#" className="text-gray-900 hover:text-gray-600">Women</a>
                <a href="#" className="text-gray-900 hover:text-gray-600">Collections</a>
                <a href="#" className="text-gray-900 hover:text-gray-600">Sale</a>
              </div>
            </div>
            
            <div className="text-2xl font-bold">LUXE</div>
            
            <div className="flex items-center space-x-4">
              <Search className="h-5 w-5 text-gray-900 cursor-pointer" />
              <User className="h-5 w-5 text-gray-900 cursor-pointer" />
              <Heart className="h-5 w-5 text-gray-900 cursor-pointer" />
              <div className="relative">
                <ShoppingBag 
                  className="h-5 w-5 text-gray-900 cursor-pointer" 
                  onClick={() => setIsCartOpen(true)}
                />
                {cart.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-black text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {cart.length}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* 3D Model Viewer Modal */}
      {selected3DProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSelected3DProduct(null)}></div>
          <div className="relative bg-white p-6 rounded-lg w-full max-w-3xl">
            <button 
              onClick={() => setSelected3DProduct(null)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X className="h-6 w-6" />
            </button>
            <h2 className="text-2xl font-bold mb-4">{selected3DProduct.name} - 3D View</h2>
            <model-viewer
              src={selected3DProduct.modelUrl}
              alt={`3D model of ${selected3DProduct.name}`}
              camera-controls
              auto-rotate
              ar
              style={{ width: '100%', height: '400px' }}
            ></model-viewer>
          </div>
        </div>
      )}

      {/* Shopping Cart Sidebar */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsCartOpen(false)}></div>
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Shopping Cart</h2>
                <button onClick={() => setIsCartOpen(false)}>
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              {cart.length === 0 ? (
                <p className="text-gray-500">Your cart is empty</p>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {cart.map(item => (
                      <div key={item.id} className="flex items-center space-x-4">
                        <img src={item.image} alt={item.name} className="w-20 h-20 object-cover" />
                        <div className="flex-1">
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-gray-600">${item.price}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <button 
                              className="px-2 py-1 border"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            >
                              -
                            </button>
                            <span>{item.quantity}</span>
                            <button 
                              className="px-2 py-1 border"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                        <button 
                          onClick={() => removeFromCart(item.id)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between mb-4">
                      <span className="font-medium">Total</span>
                      <span className="font-bold">${cartTotal.toFixed(2)}</span>
                    </div>
                    <button className="w-full bg-black text-white py-3 hover:bg-gray-800">
                      Checkout
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-black/30 z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=2070"
          alt="Hero fashion"
          className="w-full h-screen object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center z-20">
          <div className="text-center text-white">
            <h1 className="text-5xl md:text-7xl font-bold mb-4">Autumn Collection</h1>
            <p className="text-xl mb-8">Discover timeless elegance</p>
            <button className="bg-white text-black px-8 py-3 rounded-none hover:bg-gray-100 transition">
              Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* Featured Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Featured Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="relative group cursor-pointer">
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition"></div>
            <img 
              src="https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&q=80&w=1011"
              alt="Women's Collection"
              className="w-full h-96 object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-white text-2xl font-semibold">Women</span>
            </div>
          </div>
          <div className="relative group cursor-pointer">
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition"></div>
            <img 
              src="https://images.unsplash.com/photo-1617137968427-85924c800a22?auto=format&fit=crop&q=80&w=1287"
              alt="Men's Collection"
              className="w-full h-96 object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-white text-2xl font-semibold">Men</span>
            </div>
          </div>
          <div className="relative group cursor-pointer">
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition"></div>
            <img 
              src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=2070"
              alt="Accessories"
              className="w-full h-96 object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-white text-2xl font-semibold">Accessories</span>
            </div>
          </div>
        </div>
      </div>

      {/* New Arrivals */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">New Arrivals</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <div key={product.id} className="group">
                <div className="relative">
                  <img 
                    src={product.image}
                    alt={product.name}
                    className="w-full h-[400px] object-cover"
                  />
                  <div className="absolute bottom-4 left-4 right-4 flex space-x-2">
                    <button 
                      onClick={() => addToCart(product)}
                      className="flex-1 bg-white py-2 opacity-0 group-hover:opacity-100 transition"
                    >
                      Add to Cart
                    </button>
                    <button 
                      onClick={() => setSelected3DProduct(product)}
                      className="bg-white p-2 opacity-0 group-hover:opacity-100 transition"
                      title="View in 3D"
                    >
                      <View className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                <div className="mt-4">
                  <h3 className="text-lg font-medium">{product.name}</h3>
                  <p className="text-gray-600">${product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
          <p className="mb-8">Get 10% off your first order and stay updated with our latest collections</p>
          <div className="max-w-md mx-auto">
            <div className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 text-gray-900"
              />
              <button className="bg-white text-black px-6 py-2 hover:bg-gray-100">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">About LUXE</h3>
              <p className="text-gray-600">Premium clothing brand focused on quality and sustainability.</p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Customer Service</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Contact Us</li>
                <li>Shipping & Returns</li>
                <li>Size Guide</li>
                <li>FAQ</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-600">
                <li>New Arrivals</li>
                <li>Sale</li>
                <li>Gift Cards</li>
                <li>Store Locator</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Follow Us</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Instagram</li>
                <li>Facebook</li>
                <li>Twitter</li>
                <li>Pinterest</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-600">
            <p>&copy; 2024 LUXE. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;